0-README.txt

Computing and Informatics Capstone Project: Group 8


1. Contributors:

Lekko, Stephen
Malneedi, Swadesh
Morgan, Ryan
Tahsin, Tasfia

2. APIs Used:

Stephen: RAWG.io
Swadesh: IGDB
Ryan: Reddit
Tasfia: isthereanydeal

3. Associated Files:

Stephen: rawg.py
Swadesh: igdb.py
Ryan: reddit.php
Tasfia: isthereanydeal.php

4. Database Used:

capstone_db

5. Tables Used:

Stephen: rawg_api 
Swadesh: games
Ryan: reddit_api, reddit_gamedeals
Tasfia: test_isthereanyapi
